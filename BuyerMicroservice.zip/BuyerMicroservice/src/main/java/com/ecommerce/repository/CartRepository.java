package com.ecommerce.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.ecommerce.model.ShoppingCart;

@Repository
public interface CartRepository extends JpaRepository<ShoppingCart, Integer>{

	@Query(value = "DELETE FROM cart c WHERE c.buyer_id = :buyerId"
			,nativeQuery = true)
	public void emptyCart(@Param("buyerId")Integer buyerId);
	
	//public List<ShoppingCart> findAllByBuyerId(Integer buyerId);
	
	@Query(value = "SELECT * FROM cart c WHERE c.buyer_id = :buyerId"
			,nativeQuery = true)
	public List<ShoppingCart> getAllCartItems(@Param("buyerId")Integer buyerId);
		
	
}
