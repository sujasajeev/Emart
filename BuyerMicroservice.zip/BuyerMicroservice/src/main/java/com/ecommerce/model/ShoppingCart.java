package com.ecommerce.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "cart")
public class ShoppingCart implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column
	private int cartId;
	
	@Column
	private int itemId;
	
	@Column
	private int itemQuantity;
	
	@ManyToOne
	@JoinColumn(name = "buyerId")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Buyer buyerId;
	

	public ShoppingCart() {
		
	}


	public ShoppingCart(int cartId, int itemId, int itemQuantity, Buyer buyerId) {
		
		this.cartId = cartId;
		this.itemId = itemId;
		this.itemQuantity = itemQuantity;
		this.buyerId = buyerId;
	}

	
	public int getCartId() {
		return cartId;
	}


	public void setCartId(int cartId) {
		this.cartId = cartId;
	}


	public int getItemId() {
		return itemId;
	}
	
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}


	public int getItemQuantity() {
		return itemQuantity;
	}


	public void setItemQuantity(int itemQuantity) {
		this.itemQuantity = itemQuantity;
	}


	public Buyer getBuyerId() {
		return buyerId;
	}


	public void setBuyerId(Buyer buyerId) {
		this.buyerId = buyerId;
	}


	@Override
	public String toString() {
		return "ShoppingCart [cartId=" + cartId + ", itemId=" + itemId + ", itemQuantity=" + itemQuantity + ", buyerId="
				+ buyerId + "]";
	}
	
	


	
	
}
