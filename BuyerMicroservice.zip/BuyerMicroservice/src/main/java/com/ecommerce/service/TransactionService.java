package com.ecommerce.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ecommerce.model.Transactions;
import com.ecommerce.repository.BuyerRepository;
import com.ecommerce.repository.TransactionRepository;

@Service
public class TransactionService {

	@Autowired
	private TransactionRepository transactionHistory;

	@Autowired
	private BuyerRepository buyerRepository;

	public Optional<Transactions> addCartItem(Transactions transaction, Integer buyerId) {
		return buyerRepository.findById(buyerId).map(buyer -> {
			transaction.setBuyerId(buyer);
			return transactionHistory.save(transaction);
		});

	}

}
