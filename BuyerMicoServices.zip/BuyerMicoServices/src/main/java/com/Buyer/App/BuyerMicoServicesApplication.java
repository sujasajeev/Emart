package com.Buyer.App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuyerMicoServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BuyerMicoServicesApplication.class, args);
	}

}
