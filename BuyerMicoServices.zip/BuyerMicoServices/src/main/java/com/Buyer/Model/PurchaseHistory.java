package com.Buyer.Model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class PurchaseHistory implements Serializable {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int purchaseHistoryId;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="buyerId")
	private Buyer buyer;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="transactionId")
	private Transactions transactions;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name= "itemId")
	private List<Items> items;
	
	@Temporal(value=TemporalType.TIMESTAMP)
	private LocalDate purchaseHistoryDateTime;
	
	private int numberOfItems;
	
	private int purchaseHistoryRemarks;
	//foreignkey of seller id needed
	
	public PurchaseHistory()
	{
		
	}
	public PurchaseHistory(int purchaseHistoryId, Buyer buyer, Transactions transactions, List<Items> items,
			LocalDate purchaseHistoryDateTime, int numberOfItems, int purchaseHistoryRemarks) {
		
		this.purchaseHistoryId = purchaseHistoryId;
		this.buyer = buyer;
		this.transactions = transactions;
		this.items = items;
		this.purchaseHistoryDateTime = purchaseHistoryDateTime;
		this.numberOfItems = numberOfItems;
		this.purchaseHistoryRemarks = purchaseHistoryRemarks;
	}
	public int getPurchaseHistoryId() {
		return purchaseHistoryId;
	}
	public void setPurchaseHistoryId(int purchaseHistoryId) {
		this.purchaseHistoryId = purchaseHistoryId;
	}
	public Buyer getBuyer() {
		return buyer;
	}
	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}
	public Transactions getTransactions() {
		return transactions;
	}
	public void setTransactions(Transactions transactions) {
		this.transactions = transactions;
	}
	public List<Items> getItems() {
		return items;
	}
	public void setItems(List<Items> items) {
		this.items = items;
	}
	public LocalDate getPurchaseHistoryDateTime() {
		return purchaseHistoryDateTime;
	}
	public void setPurchaseHistoryDateTime(LocalDate purchaseHistoryDateTime) {
		this.purchaseHistoryDateTime = purchaseHistoryDateTime;
	}
	public int getNumberOfItems() {
		return numberOfItems;
	}
	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}
	public int getPurchaseHistoryRemarks() {
		return purchaseHistoryRemarks;
	}
	public void setPurchaseHistoryRemarks(int purchaseHistoryRemarks) {
		this.purchaseHistoryRemarks = purchaseHistoryRemarks;
	}
	@Override
	public String toString() {
		return "PurchaseHistory [purchaseHistoryId=" + purchaseHistoryId + ", buyer=" + buyer + ", transactions="
				+ transactions + ", items=" + items + ", purchaseHistoryDateTime=" + purchaseHistoryDateTime
				+ ", numberOfItems=" + numberOfItems + ", purchaseHistoryRemarks=" + purchaseHistoryRemarks + "]";
	}
	
	
	 
	


}
