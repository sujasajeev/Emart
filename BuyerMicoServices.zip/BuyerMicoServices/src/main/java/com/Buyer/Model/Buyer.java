package com.Buyer.Model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Buyer implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int buyerId;
	private String buyerName;
	private String buyerUserName;
	private String buyerPassword;
	private String buyerEmailId;
	private long buyerMobileNumber;
	@Temporal(value=TemporalType.TIMESTAMP)
	private LocalDate createdDateTime;
	
	public Buyer() {
		
	}

	public Buyer(int buyerId, String buyerName, String buyerUserName, String buyerPassword, String buyerEmailId,
			long buyerMobileNumber, LocalDate createdDateTime) {
		
		this.buyerId = buyerId;
		this.buyerName = buyerName;
		this.buyerUserName = buyerUserName;
		this.buyerPassword = buyerPassword;
		this.buyerEmailId = buyerEmailId;
		this.buyerMobileNumber = buyerMobileNumber;
		this.createdDateTime = createdDateTime;
	}

	public int getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(int buyerId) {
		this.buyerId = buyerId;
	}

	public String getBuyerName() {
		return buyerName;
	}

	public void setBuyerName(String buyerName) {
		this.buyerName = buyerName;
	}

	public String getBuyerUserName() {
		return buyerUserName;
	}

	public void setBuyerUserName(String buyerUserName) {
		this.buyerUserName = buyerUserName;
	}

	public String getBuyerPassword() {
		return buyerPassword;
	}

	public void setBuyerPassword(String buyerPassword) {
		this.buyerPassword = buyerPassword;
	}

	public String getBuyerEmailId() {
		return buyerEmailId;
	}

	public void setBuyerEmailId(String buyerEmailId) {
		this.buyerEmailId = buyerEmailId;
	}

	public long getBuyerMobileNumber() {
		return buyerMobileNumber;
	}

	public void setBuyerMobileNumber(long buyerMobileNumber) {
		this.buyerMobileNumber = buyerMobileNumber;
	}

	public LocalDate getCreatedDateTime() {
		return createdDateTime;
	}

	public void setCreatedDateTime(LocalDate createdDateTime) {
		this.createdDateTime = createdDateTime;
	}

	@Override
	public String toString() {
		return "Buyer [buyerId=" + buyerId + ", buyerName=" + buyerName + ", buyerUserName=" + buyerUserName
				+ ", buyerPassword=" + buyerPassword + ", buyerEmailId=" + buyerEmailId + ", buyerMobileNumber="
				+ buyerMobileNumber + ", createdDateTime=" + createdDateTime + "]";
	}
	
	
	
}
