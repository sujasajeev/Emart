package com.Buyer.Model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Transactions implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transactionId;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="buyerId")
	private Buyer buyer;
	
	private String transactionType;
	
	private float totalAmount;
	
	@Temporal(value=TemporalType.TIMESTAMP)
	private LocalDate transactionDateTime;
	
	private String transactionRemarks;
	//forign key of seller id is needed
	
	public Transactions()
	{
		
	}
	public Transactions(int transactionId, Buyer buyer, String transactionType, float totalAmount,
			LocalDate transactionDateTime, String transactionRemarks) {
		
		this.transactionId = transactionId;
		this.buyer = buyer;
		this.transactionType = transactionType;
		this.totalAmount = totalAmount;
		this.transactionDateTime = transactionDateTime;
		this.transactionRemarks = transactionRemarks;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public Buyer getBuyer() {
		return buyer;
	}
	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public float getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(float totalAmount) {
		this.totalAmount = totalAmount;
	}
	public LocalDate getTransactionDateTime() {
		return transactionDateTime;
	}
	public void setTransactionDateTime(LocalDate transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	public String getTransactionRemarks() {
		return transactionRemarks;
	}
	public void setTransactionRemarks(String transactionRemarks) {
		this.transactionRemarks = transactionRemarks;
	}
	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", buyer=" + buyer + ", transactionType="
				+ transactionType + ", totalAmount=" + totalAmount + ", transactionDateTime=" + transactionDateTime
				+ ", transactionRemarks=" + transactionRemarks + "]";
	}
	
	
	

}
