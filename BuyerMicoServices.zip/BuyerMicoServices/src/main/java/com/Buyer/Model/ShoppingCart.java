package com.Buyer.Model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;




@Entity
public class ShoppingCart implements Serializable  {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int shoppingCartId;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name= "itemId")
	private List<Items> items;
	
	private int cartItemQuantity;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="buyerId")
	private Buyer buyer;
	
	public ShoppingCart()
	{
		
	}

	public ShoppingCart(int shoppingCartId, List<Items> items, int cartItemQuantity, Buyer buyer) {
		
		this.shoppingCartId = shoppingCartId;
		this.items = items;
		this.cartItemQuantity = cartItemQuantity;
		this.buyer = buyer;
	}

	public int getShoppingCartId() {
		return shoppingCartId;
	}

	public void setShoppingCartId(int shoppingCartId) {
		this.shoppingCartId = shoppingCartId;
	}

	public List<Items> getItems() {
		return items;
	}

	public void setItems(List<Items> items) {
		this.items = items;
	}

	public int getCartItemQuantity() {
		return cartItemQuantity;
	}

	public void setCartItemQuantity(int cartItemQuantity) {
		this.cartItemQuantity = cartItemQuantity;
	}

	public Buyer getBuyer() {
		return buyer;
	}

	public void setBuyer(Buyer buyer) {
		this.buyer = buyer;
	}

	@Override
	public String toString() {
		return "ShoppingCart [shoppingCartId=" + shoppingCartId + ", items=" + items + ", cartItemQuantity="
				+ cartItemQuantity + ", buyer=" + buyer + "]";
	}
	
	
	
	
	
	

}
