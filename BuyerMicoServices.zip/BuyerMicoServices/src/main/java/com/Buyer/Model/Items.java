package com.Buyer.Model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Items implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int itemId;
	private String itemName;
    private float itemPrice;
	private String itemDescription;
	private int itemStockNumber;
	private String itemRemarks;
	// include category id and subcategory id as foreign key.
	
	public Items()
	{
		
	}
	public Items(int itemId, String itemName, float itemPrice, String itemDescription, int itemStockNumber,
			String itemRemarks) {
		
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.itemDescription = itemDescription;
		this.itemStockNumber = itemStockNumber;
		this.itemRemarks = itemRemarks;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public float getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(float itemPrice) {
		this.itemPrice = itemPrice;
	}
	public String getItemDescription() {
		return itemDescription;
	}
	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}
	public int getItemStockNumber() {
		return itemStockNumber;
	}
	public void setItemStockNumber(int itemStockNumber) {
		this.itemStockNumber = itemStockNumber;
	}
	public String getItemRemarks() {
		return itemRemarks;
	}
	public void setItemRemarks(String itemRemarks) {
		this.itemRemarks = itemRemarks;
	}
	@Override
	public String toString() {
		return "Items [itemId=" + itemId + ", itemName=" + itemName + ", itemPrice=" + itemPrice + ", itemDescription="
				+ itemDescription + ", itemStockNumber=" + itemStockNumber + ", itemRemarks=" + itemRemarks + "]";
	}
	
	
	
	

	
	


}
